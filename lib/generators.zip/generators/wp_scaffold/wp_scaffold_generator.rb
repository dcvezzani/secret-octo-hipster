class WpScaffoldGenerator < Rails::Generators::NamedBase
  source_root File.expand_path('./templates', __FILE__)

  hook_for :scaffold_controller, :in => :rails, :required => true
end
