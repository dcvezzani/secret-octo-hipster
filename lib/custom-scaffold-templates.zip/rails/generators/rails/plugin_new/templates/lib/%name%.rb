<% if full? -%>
require "<%= name %>/engine"

<% end -%>
module <%= camelized %>
end
