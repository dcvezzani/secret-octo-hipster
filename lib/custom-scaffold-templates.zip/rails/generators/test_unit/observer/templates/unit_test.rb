require 'test_helper'

<% module_namespacing do -%>
class <%= class_name %>ObserverTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
<% end -%>
